﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _00012252
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tb_SmartphoneBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            SaveData();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {                                               
                this.tb_OSTableAdapter.Fill(this.smartphonesDataSet.tb_OS);
                this.tb_SmartphoneTableAdapter.Fill(this.smartphonesDataSet.tb_Smartphone);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnFirst_Click(object sender, EventArgs e)     //creating buttons to help navigate the panel
        {
            tb_SmartphoneBindingSource.MoveFirst();                  
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            tb_SmartphoneBindingSource.MovePrevious();                 
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            tb_SmartphoneBindingSource.MoveNext();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            tb_SmartphoneBindingSource.MoveLast();
        }

        private void EnableDisableButtons()                     // Enablling and disabling buttons as the record moves to the last or to the first
        {
            if (tb_SmartphoneBindingSource.Position==0)   // if the position is at 0 meaning the record is at the top, the first two buttons will be disabled
            {                                                   //disallowing the user to click them
                btnFirst.Enabled = false;
                btnPrevious.Enabled = false;
            }
            else
            {
                btnFirst.Enabled = true;                            // if the records are in the middle of the list, the buttons will be enabled
                btnPrevious.Enabled = true;
            }
            if (tb_SmartphoneBindingSource.Position == tb_SmartphoneBindingSource.Count -1) // if the position is at 0 meaning the record is at the bottom
            {                                                               //the last two buttons will be disabled, disallowibg the user to click them
                btnNext.Enabled = false;
                btnLast.Enabled = false;
            }
            else
            {                                                        // if the records are in the middle of the list, the buttons will be enabled
                btnNext.Enabled = true;
                btnLast.Enabled = true;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (tb_SmartphoneBindingSource.Count==0)  // if there is no record, a message will be displayed that there is nothing to delete
            {
                MessageBox.Show("Nothing to delete");
            }
            else                                                 //if there is a record, a popup will show asking the user if he is sure
            {
                var userResponce = MessageBox.Show("Sure?", "Delete", MessageBoxButtons.YesNo);   //storing user response and if its a yes, then
                    if (userResponce==DialogResult.Yes)                                              // removing the record   
                    {
                        tb_SmartphoneBindingSource.RemoveCurrent();                                            
                    }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)     //upon clicking on the button, SaveData() function will activate
        {
            SaveData();
        }

        private void SaveData()
        {
            if (this.Validate())                                //if the input is valid
            {
                try
                {
                    this.tb_SmartphoneBindingSource.EndEdit();      // ending all the edits
                    this.tableAdapterManager.UpdateAll(this.smartphonesDataSet);     // updating all the records
                    MessageBox.Show("Saved");                       // displaying the message to ensure minimum service calls

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);           // if any error, the exception message will appear
                }
            }
        
        }

        private void tb_SmartphoneBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            EnableDisableButtons();            // making the EnableDisableButtons work, amazng
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)    //upon closing the form, the following happens
        {
            if (Validate())                                         //if the input is valid
            {
                this.tb_SmartphoneBindingSource.EndEdit();          // all the edits will be ended
                if (smartphonesDataSet.HasChanges())                // if there has been changes to the database
                {                                           // message will be displayed asking if the user wants to save the data before closing
                    if (MessageBox.Show("Save changes before closing?" , "Save" , MessageBoxButtons.YesNo)==DialogResult.Yes) // if the answer is yes
                    {
                        SaveData();             // SaveData() will run, saving the data
                    }
                }
            }
            else
            {                                       // if input is not validated and/or if answer to dialog result is no or database has no changes
                e.Cancel = true;                // upon closing, the data will not be changed
            }    


        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var selectedOS = ((DataRowView)cbxNewOS.SelectedItem).Row; // adding new record of a smartphone to the database
            smartphonesDataSet.tb_Smartphone.Addtb_SmartphoneRow(
                tbxNewBrand.Text,
                tbxNewModel.Text,
                (int)nudNewPrice.Value,
                (int)nudNewNoInStock.Value,
                (SmartphonesDataSet.tb_OSRow)selectedOS);
                
        }

        private void tbxFilter_TextChanged(object sender, EventArgs e)  // filtering the database to search for text like in tbxFilter
        {
            tb_SmartphoneBindingSource.Filter = $" Model_12252 LIKE '{tbxFilter.Text}%'";
        }


        //validation below
        private void tbxBrand_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(tbxBrand.Text))
            {
                MessageBox.Show("Brand cannot be empty");
                e.Cancel = true;
            }    
        }

        private void tbxModel_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(tbxModel.Text))
            {
                MessageBox.Show("Model cannot be empty");
                e.Cancel = true;
            }
        }

        private void tbxNewBrand_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(tbxNewBrand.Text))
            {
                MessageBox.Show("Brand cannot be empty");
                e.Cancel = true;
            }
        }

        private void tbxNewModel_Validating(object sender, CancelEventArgs e)
        {
            if (String.IsNullOrEmpty(tbxNewModel.Text))
            {
                MessageBox.Show("Model cannot be empty");
                e.Cancel = true;
            }

        }

        private void nudPrice_Validating(object sender, CancelEventArgs e)
        {

        }
    }
}
