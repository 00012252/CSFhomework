﻿namespace _00012252
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.Label brand_12252Label;
            System.Windows.Forms.Label model_12252Label;
            System.Windows.Forms.Label price_12252Label;
            System.Windows.Forms.Label numberInStock_12252Label;
            System.Windows.Forms.Label oS_12252Label;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label5;
            this.smartphonesDataSet = new _00012252.SmartphonesDataSet();
            this.tb_SmartphoneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tb_SmartphoneTableAdapter = new _00012252.SmartphonesDataSetTableAdapters.tb_SmartphoneTableAdapter();
            this.tableAdapterManager = new _00012252.SmartphonesDataSetTableAdapters.TableAdapterManager();
            this.tb_SmartphoneBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.tb_SmartphoneBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.tbxModel = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnLast = new System.Windows.Forms.Button();
            this.tbxBrand = new System.Windows.Forms.TextBox();
            this.cbxOs = new System.Windows.Forms.ComboBox();
            this.tbOSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tb_OSTableAdapter = new _00012252.SmartphonesDataSetTableAdapters.tb_OSTableAdapter();
            this.nudNoInStock = new System.Windows.Forms.NumericUpDown();
            this.nudPrice = new System.Windows.Forms.NumericUpDown();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.gbAdd = new System.Windows.Forms.GroupBox();
            this.tbxNewModel = new System.Windows.Forms.TextBox();
            this.tbxNewBrand = new System.Windows.Forms.TextBox();
            this.cbxNewOS = new System.Windows.Forms.ComboBox();
            this.nudNewNoInStock = new System.Windows.Forms.NumericUpDown();
            this.nudNewPrice = new System.Windows.Forms.NumericUpDown();
            this.tbOSBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.btnAdd = new System.Windows.Forms.Button();
            this.tbxFilter = new System.Windows.Forms.TextBox();
            brand_12252Label = new System.Windows.Forms.Label();
            model_12252Label = new System.Windows.Forms.Label();
            price_12252Label = new System.Windows.Forms.Label();
            numberInStock_12252Label = new System.Windows.Forms.Label();
            oS_12252Label = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.smartphonesDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_SmartphoneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_SmartphoneBindingNavigator)).BeginInit();
            this.tb_SmartphoneBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbOSBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNoInStock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPrice)).BeginInit();
            this.gbAdd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNewNoInStock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNewPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbOSBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // smartphonesDataSet
            // 
            this.smartphonesDataSet.DataSetName = "SmartphonesDataSet";
            this.smartphonesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tb_SmartphoneBindingSource
            // 
            this.tb_SmartphoneBindingSource.DataMember = "tb_Smartphone";
            this.tb_SmartphoneBindingSource.DataSource = this.smartphonesDataSet;
            this.tb_SmartphoneBindingSource.CurrentChanged += new System.EventHandler(this.tb_SmartphoneBindingSource_CurrentChanged);
            // 
            // tb_SmartphoneTableAdapter
            // 
            this.tb_SmartphoneTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tb_OSTableAdapter = this.tb_OSTableAdapter;
            this.tableAdapterManager.tb_SmartphoneTableAdapter = this.tb_SmartphoneTableAdapter;
            this.tableAdapterManager.UpdateOrder = _00012252.SmartphonesDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tb_SmartphoneBindingNavigator
            // 
            this.tb_SmartphoneBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tb_SmartphoneBindingNavigator.BindingSource = this.tb_SmartphoneBindingSource;
            this.tb_SmartphoneBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tb_SmartphoneBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tb_SmartphoneBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tb_SmartphoneBindingNavigatorSaveItem});
            this.tb_SmartphoneBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tb_SmartphoneBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tb_SmartphoneBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tb_SmartphoneBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tb_SmartphoneBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tb_SmartphoneBindingNavigator.Name = "tb_SmartphoneBindingNavigator";
            this.tb_SmartphoneBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tb_SmartphoneBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.tb_SmartphoneBindingNavigator.TabIndex = 0;
            this.tb_SmartphoneBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // tb_SmartphoneBindingNavigatorSaveItem
            // 
            this.tb_SmartphoneBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tb_SmartphoneBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tb_SmartphoneBindingNavigatorSaveItem.Image")));
            this.tb_SmartphoneBindingNavigatorSaveItem.Name = "tb_SmartphoneBindingNavigatorSaveItem";
            this.tb_SmartphoneBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.tb_SmartphoneBindingNavigatorSaveItem.Text = "Save Data";
            this.tb_SmartphoneBindingNavigatorSaveItem.Click += new System.EventHandler(this.tb_SmartphoneBindingNavigatorSaveItem_Click);
            // 
            // brand_12252Label
            // 
            brand_12252Label.AutoSize = true;
            brand_12252Label.Location = new System.Drawing.Point(222, 60);
            brand_12252Label.Name = "brand_12252Label";
            brand_12252Label.Size = new System.Drawing.Size(71, 13);
            brand_12252Label.TabIndex = 3;
            brand_12252Label.Text = "Brand 12252:";
            // 
            // model_12252Label
            // 
            model_12252Label.AutoSize = true;
            model_12252Label.Location = new System.Drawing.Point(222, 86);
            model_12252Label.Name = "model_12252Label";
            model_12252Label.Size = new System.Drawing.Size(72, 13);
            model_12252Label.TabIndex = 5;
            model_12252Label.Text = "Model 12252:";
            // 
            // tbxModel
            // 
            this.tbxModel.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tb_SmartphoneBindingSource, "Model_12252", true));
            this.tbxModel.Location = new System.Drawing.Point(351, 79);
            this.tbxModel.Name = "tbxModel";
            this.tbxModel.Size = new System.Drawing.Size(100, 20);
            this.tbxModel.TabIndex = 6;
            this.tbxModel.Validating += new System.ComponentModel.CancelEventHandler(this.tbxModel_Validating);
            // 
            // price_12252Label
            // 
            price_12252Label.AutoSize = true;
            price_12252Label.Location = new System.Drawing.Point(222, 112);
            price_12252Label.Name = "price_12252Label";
            price_12252Label.Size = new System.Drawing.Size(67, 13);
            price_12252Label.TabIndex = 7;
            price_12252Label.Text = "Price 12252:";
            // 
            // numberInStock_12252Label
            // 
            numberInStock_12252Label.AutoSize = true;
            numberInStock_12252Label.Location = new System.Drawing.Point(222, 138);
            numberInStock_12252Label.Name = "numberInStock_12252Label";
            numberInStock_12252Label.Size = new System.Drawing.Size(123, 13);
            numberInStock_12252Label.TabIndex = 9;
            numberInStock_12252Label.Text = "Number In Stock 12252:";
            // 
            // oS_12252Label
            // 
            oS_12252Label.AutoSize = true;
            oS_12252Label.Location = new System.Drawing.Point(222, 164);
            oS_12252Label.Name = "oS_12252Label";
            oS_12252Label.Size = new System.Drawing.Size(58, 13);
            oS_12252Label.TabIndex = 11;
            oS_12252Label.Text = "OS 12252:";
            // 
            // listBox1
            // 
            this.listBox1.DataSource = this.tb_SmartphoneBindingSource;
            this.listBox1.DisplayMember = "Model_12252";
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(26, 79);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(161, 121);
            this.listBox1.TabIndex = 13;
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(26, 206);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(36, 23);
            this.btnFirst.TabIndex = 14;
            this.btnFirst.Text = "<<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(68, 206);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(35, 23);
            this.btnPrevious.TabIndex = 15;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(109, 206);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(34, 23);
            this.btnNext.TabIndex = 16;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(149, 206);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(38, 23);
            this.btnLast.TabIndex = 17;
            this.btnLast.Text = ">>";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // tbxBrand
            // 
            this.tbxBrand.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tb_SmartphoneBindingSource, "Brand_12252", true));
            this.tbxBrand.Location = new System.Drawing.Point(351, 53);
            this.tbxBrand.Name = "tbxBrand";
            this.tbxBrand.Size = new System.Drawing.Size(100, 20);
            this.tbxBrand.TabIndex = 4;
            this.tbxBrand.Validating += new System.ComponentModel.CancelEventHandler(this.tbxBrand_Validating);
            // 
            // cbxOs
            // 
            this.cbxOs.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tb_SmartphoneBindingSource, "OS_12252", true));
            this.cbxOs.DataSource = this.tbOSBindingSource;
            this.cbxOs.DisplayMember = "OS_12252";
            this.cbxOs.FormattingEnabled = true;
            this.cbxOs.Location = new System.Drawing.Point(351, 164);
            this.cbxOs.Name = "cbxOs";
            this.cbxOs.Size = new System.Drawing.Size(100, 21);
            this.cbxOs.TabIndex = 18;
            this.cbxOs.ValueMember = "Id_12252";
            // 
            // tbOSBindingSource
            // 
            this.tbOSBindingSource.DataMember = "tb_OS";
            this.tbOSBindingSource.DataSource = this.smartphonesDataSet;
            // 
            // tb_OSTableAdapter
            // 
            this.tb_OSTableAdapter.ClearBeforeFill = true;
            // 
            // nudNoInStock
            // 
            this.nudNoInStock.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.tb_SmartphoneBindingSource, "NumberInStock_12252", true));
            this.nudNoInStock.Location = new System.Drawing.Point(351, 131);
            this.nudNoInStock.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.nudNoInStock.Name = "nudNoInStock";
            this.nudNoInStock.Size = new System.Drawing.Size(99, 20);
            this.nudNoInStock.TabIndex = 19;
            // 
            // nudPrice
            // 
            this.nudPrice.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.tb_SmartphoneBindingSource, "Price_12252", true));
            this.nudPrice.Location = new System.Drawing.Point(351, 105);
            this.nudPrice.Maximum = new decimal(new int[] {
            -727379969,
            232,
            0,
            0});
            this.nudPrice.Name = "nudPrice";
            this.nudPrice.Size = new System.Drawing.Size(100, 20);
            this.nudPrice.TabIndex = 20;
            this.nudPrice.Validating += new System.ComponentModel.CancelEventHandler(this.nudPrice_Validating);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(254, 206);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 21;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(351, 206);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 22;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // gbAdd
            // 
            this.gbAdd.Controls.Add(this.btnAdd);
            this.gbAdd.Controls.Add(this.nudNewNoInStock);
            this.gbAdd.Controls.Add(label1);
            this.gbAdd.Controls.Add(label2);
            this.gbAdd.Controls.Add(this.nudNewPrice);
            this.gbAdd.Controls.Add(label3);
            this.gbAdd.Controls.Add(this.tbxNewModel);
            this.gbAdd.Controls.Add(this.cbxNewOS);
            this.gbAdd.Controls.Add(label4);
            this.gbAdd.Controls.Add(this.tbxNewBrand);
            this.gbAdd.Controls.Add(label5);
            this.gbAdd.Location = new System.Drawing.Point(480, 28);
            this.gbAdd.Name = "gbAdd";
            this.gbAdd.Size = new System.Drawing.Size(263, 213);
            this.gbAdd.TabIndex = 23;
            this.gbAdd.TabStop = false;
            this.gbAdd.Text = "Add";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(9, 136);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(58, 13);
            label1.TabIndex = 11;
            label1.Text = "OS 12252:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(9, 110);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(123, 13);
            label2.TabIndex = 9;
            label2.Text = "Number In Stock 12252:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(9, 84);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(67, 13);
            label3.TabIndex = 7;
            label3.Text = "Price 12252:";
            // 
            // tbxNewModel
            // 
            this.tbxNewModel.Location = new System.Drawing.Point(138, 51);
            this.tbxNewModel.Name = "tbxNewModel";
            this.tbxNewModel.Size = new System.Drawing.Size(100, 20);
            this.tbxNewModel.TabIndex = 6;
            this.tbxNewModel.Validating += new System.ComponentModel.CancelEventHandler(this.tbxNewModel_Validating);
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(9, 58);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(72, 13);
            label4.TabIndex = 5;
            label4.Text = "Model 12252:";
            // 
            // tbxNewBrand
            // 
            this.tbxNewBrand.Location = new System.Drawing.Point(138, 25);
            this.tbxNewBrand.Name = "tbxNewBrand";
            this.tbxNewBrand.Size = new System.Drawing.Size(100, 20);
            this.tbxNewBrand.TabIndex = 4;
            this.tbxNewBrand.Validating += new System.ComponentModel.CancelEventHandler(this.tbxNewBrand_Validating);
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(9, 32);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(71, 13);
            label5.TabIndex = 3;
            label5.Text = "Brand 12252:";
            // 
            // cbxNewOS
            // 
            this.cbxNewOS.DataSource = this.tbOSBindingSource1;
            this.cbxNewOS.DisplayMember = "OS_12252";
            this.cbxNewOS.FormattingEnabled = true;
            this.cbxNewOS.Location = new System.Drawing.Point(138, 136);
            this.cbxNewOS.Name = "cbxNewOS";
            this.cbxNewOS.Size = new System.Drawing.Size(100, 21);
            this.cbxNewOS.TabIndex = 18;
            // 
            // nudNewNoInStock
            // 
            this.nudNewNoInStock.Location = new System.Drawing.Point(138, 103);
            this.nudNewNoInStock.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.nudNewNoInStock.Name = "nudNewNoInStock";
            this.nudNewNoInStock.Size = new System.Drawing.Size(99, 20);
            this.nudNewNoInStock.TabIndex = 19;
            // 
            // nudNewPrice
            // 
            this.nudNewPrice.Location = new System.Drawing.Point(138, 77);
            this.nudNewPrice.Maximum = new decimal(new int[] {
            1410065407,
            2,
            0,
            0});
            this.nudNewPrice.Name = "nudNewPrice";
            this.nudNewPrice.Size = new System.Drawing.Size(100, 20);
            this.nudNewPrice.TabIndex = 20;
            // 
            // tbOSBindingSource1
            // 
            this.tbOSBindingSource1.DataMember = "tb_OS";
            this.tbOSBindingSource1.DataSource = this.smartphonesDataSet;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(96, 178);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 21;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // tbxFilter
            // 
            this.tbxFilter.Location = new System.Drawing.Point(27, 53);
            this.tbxFilter.Name = "tbxFilter";
            this.tbxFilter.Size = new System.Drawing.Size(160, 20);
            this.tbxFilter.TabIndex = 24;
            this.tbxFilter.TextChanged += new System.EventHandler(this.tbxFilter_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tbxFilter);
            this.Controls.Add(this.gbAdd);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.nudPrice);
            this.Controls.Add(this.nudNoInStock);
            this.Controls.Add(this.cbxOs);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(brand_12252Label);
            this.Controls.Add(this.tbxBrand);
            this.Controls.Add(model_12252Label);
            this.Controls.Add(this.tbxModel);
            this.Controls.Add(price_12252Label);
            this.Controls.Add(numberInStock_12252Label);
            this.Controls.Add(oS_12252Label);
            this.Controls.Add(this.tb_SmartphoneBindingNavigator);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.smartphonesDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_SmartphoneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_SmartphoneBindingNavigator)).EndInit();
            this.tb_SmartphoneBindingNavigator.ResumeLayout(false);
            this.tb_SmartphoneBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbOSBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNoInStock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPrice)).EndInit();
            this.gbAdd.ResumeLayout(false);
            this.gbAdd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNewNoInStock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNewPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbOSBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SmartphonesDataSet smartphonesDataSet;
        private System.Windows.Forms.BindingSource tb_SmartphoneBindingSource;
        private SmartphonesDataSetTableAdapters.tb_SmartphoneTableAdapter tb_SmartphoneTableAdapter;
        private SmartphonesDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tb_SmartphoneBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tb_SmartphoneBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox tbxModel;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnLast;
        private SmartphonesDataSetTableAdapters.tb_OSTableAdapter tb_OSTableAdapter;
        private System.Windows.Forms.TextBox tbxBrand;
        private System.Windows.Forms.ComboBox cbxOs;
        private System.Windows.Forms.BindingSource tbOSBindingSource;
        private System.Windows.Forms.NumericUpDown nudNoInStock;
        private System.Windows.Forms.NumericUpDown nudPrice;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox gbAdd;
        private System.Windows.Forms.NumericUpDown nudNewNoInStock;
        private System.Windows.Forms.NumericUpDown nudNewPrice;
        private System.Windows.Forms.TextBox tbxNewModel;
        private System.Windows.Forms.ComboBox cbxNewOS;
        private System.Windows.Forms.TextBox tbxNewBrand;
        private System.Windows.Forms.BindingSource tbOSBindingSource1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox tbxFilter;
    }
}

